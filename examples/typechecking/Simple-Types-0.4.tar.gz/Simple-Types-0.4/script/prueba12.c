int a,b[10][20],e[10][20];

int f(char c) {
  e[5] = b[5];
  a = b[1][2];
}

