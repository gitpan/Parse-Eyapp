int c[20][30], d;

int f(int a, int b) {
  return
     (a+b)*
     d*
     c[5];
}
