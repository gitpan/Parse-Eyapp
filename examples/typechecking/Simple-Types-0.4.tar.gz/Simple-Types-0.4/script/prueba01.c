int a[20],b,e[10];

g() {}

int f(char c) {
char d;
 c = 'X';
 e[d][b] = 'A'+c;
 { 
   int d;
   d = a + b;
 }
 c = d * 2;
 return c;
}

