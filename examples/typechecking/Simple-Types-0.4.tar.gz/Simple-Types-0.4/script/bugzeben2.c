int a,b;

int f(char c) {
  int d;

  c = d * 2;

  while (a < b) {
    if (4 == b) {
      continue;
    }
    else {
      break;
    }
  }
  {
  /*  { {{continue;}}} */
  }
  return c;
}

